# How to use MapJS 2 with WebPack

1. run `npm install` to grab the dependencies
2. run `npm run pack-js` to package MAPJS and all the dependencies into a single JS file
3. open `index.html` in your browser

## How it works

Check out [src/start.js](src/start.js) to see how the page is wired up and initialised.

